#!/usr/bin/env python3
"""Recompile EAS, derive its deployment immutables, and regenerate pinned artifacts.

The repository scaffold compiler emits a runtime template. This benchmark additionally
pins the actual mainnet runtime, as requested; only compiler-declared immutable sites
are patched, using values derived from the constructor rather than copied from code.
"""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
SOURCES = DIRECTORY.parent / "eas-contracts"
MODULE = "Benchmarks.EAS.EAS"
sys.path.insert(0, str(ROOT / "scripts"))
import scaffold
from evm_tools import keccak256


def read_json(name):
    return json.loads((DIRECTORY / name).read_text())


def run_script(name, *args):
    subprocess.run([sys.executable, str(ROOT / "scripts" / name), *map(str, args)],
                   cwd=ROOT, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--solc", help="recompile with this verified Solidity 0.8.18 binary")
    args = parser.parse_args()
    if args.solc:
        release = read_json("provenance/compiler-release.json")
        digest = hashlib.sha256(Path(args.solc).read_bytes()).hexdigest()
        assert digest == release["sha256"].removeprefix("0x"), "wrong solc binary"
        settings = read_json("provenance/verification-input.json")["settings"].copy()
        settings.pop("outputSelection", None)
        run_script("scaffold.py", "compile", "--dir", DIRECTORY, "--solc", args.solc,
                   "--sources-root", SOURCES, "--main", "contracts/EAS.sol", "--contract", "EAS",
                   "--runs", 1000000, "--via-ir", "--metadata-hash", "none", "--all-sources",
                   "--settings-json", json.dumps(settings))

    deployment = read_json("provenance/upstream-deployment.json")
    verification = read_json("provenance/blockscout-verification.json")
    build = read_json("EAS.build.json")
    assert build["settings"]["viaIR"] is True
    template = bytes.fromhex(deployment["deployedBytecode"].removeprefix("0x"))
    current = bytes.fromhex((DIRECTORY / "runtime.hex").read_text().strip())
    deployed = bytes.fromhex(verification["deployed_bytecode"].removeprefix("0x"))
    assert current in (template, deployed), "compiled runtime differs from pinned deployment"
    creation = bytes.fromhex((DIRECTORY / "creation.hex").read_text().strip())
    assert creation == bytes.fromhex(deployment["bytecode"].removeprefix("0x"))
    registry = int(deployment["args"][0], 16)
    address = int(deployment["address"], 16)
    word = lambda n: n.to_bytes(32, "big")
    name_hash = keccak256(b"EAS")
    version_hash = keccak256(b"0.26")
    type_hash = keccak256(b"EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")
    values = {
        "_HASHED_NAME": name_hash,
        "_HASHED_VERSION": version_hash,
        "_TYPE_HASH": type_hash,
        "_CACHED_CHAIN_ID": word(1),
        "_CACHED_THIS": word(address),
        "_CACHED_DOMAIN_SEPARATOR": keccak256(type_hash + name_hash + version_hash + word(1) + word(address)),
        "_schemaRegistry": word(registry),
    }
    patched = bytearray(template)
    for immutable in build["immutables"]:
        value = values[immutable["name"]]
        for offset in immutable["offsets"]:
            assert template[offset:offset + 32] == bytes(32)
            patched[offset:offset + 32] = value
    assert bytes(patched) == deployed, "runtime does not match deployed code byte for byte"
    rpc = read_json("provenance/mainnet-rpc.json")
    assert deployed == bytes.fromhex(rpc["response"]["result"].removeprefix("0x"))
    assert creation + word(registry) == bytes.fromhex(verification["creation_bytecode"].removeprefix("0x"))
    (DIRECTORY / "runtime-template.hex").write_text(template.hex() + "\n")
    (DIRECTORY / "runtime.hex").write_text(patched.hex() + "\n")
    comparison = {
        "address": deployment["address"], "chainId": 1,
        "sourceCommit": "aefff5aea2b61b4d86f5af016bc51b6acf3685fc",
        "compiler": build["compiler"]["version"],
        "runtimeBytes": len(deployed),
        "runtimeSha256": hashlib.sha256(deployed).hexdigest(),
        "metadataTail": deployed[-12:].hex(),
        "runtimeByteExactIncludingMetadata": True,
        "independentRpcByteExact": True,
        "creationWithArgumentsByteExact": True,
        "immutablesDerivedFromConstructor": {k: "0x" + v.hex() for k, v in values.items()},
        "noViaIrRuntimeBytes": 16313,
        "noViaIrMatchesDeployment": False,
        "verificationSource": "Blockscout verification record; Etherscan returned HTTP 403",
    }
    (DIRECTORY / "provenance/comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
    scaffold.write_hashes(DIRECTORY, "EAS", SOURCES)
    with (DIRECTORY / "sources.sha256").open("a") as hashes:
        for path in [DIRECTORY / "runtime-template.hex", *sorted((DIRECTORY / "provenance").glob("*.json"))]:
            hashes.write(f"{scaffold.sha256_file(path)}  {scaffold.rel_to_root(path)}\n")
    for step in ("lean", "blocks", "check"):
        run_script("scaffold.py", step, "--dir", DIRECTORY, "--module", MODULE, "--force")
    print(f"ok   mainnet runtime: {len(deployed)} bytes, metadata included; constructor immutables independently derived")


if __name__ == "__main__":
    main()
